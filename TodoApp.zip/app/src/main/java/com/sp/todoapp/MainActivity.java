package com.sp.todoapp;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskClickListener {

    private RecyclerView recyclerView;
    private TextView tvEmptyState;
    private FloatingActionButton fabAddTask;
    private List<Task> taskList;
    private TaskAdapter taskAdapter;
    private SharedPreferences sharedPreferences;

    private static final String PREF_NAME = "TodoPrefs";
    private static final String KEY_TASKS = "tasks_json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerViewTasks);
        tvEmptyState = findViewById(R.id.tvEmptyState);
        fabAddTask = findViewById(R.id.fabAddTask);

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        taskList = new ArrayList<>();
        loadTasks();

        taskAdapter = new TaskAdapter(taskList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(taskAdapter);

        updateEmptyState();

        fabAddTask.setOnClickListener(v -> showAddTaskDialog());
    }

    private void showAddTaskDialog() {
        Dialog dialog = new Dialog(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        dialog.setContentView(dialogView);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        EditText etTitle = dialogView.findViewById(R.id.etTaskTitle);
        EditText etDesc = dialogView.findViewById(R.id.etTaskDesc);
        Button btnAdd = dialogView.findViewById(R.id.btnAdd);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);

        btnAdd.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            if (!title.isEmpty()) {
                String desc = etDesc.getText().toString().trim();
                Task newTask = new Task(UUID.randomUUID().toString(), title, desc, false);
                taskList.add(0, newTask);
                taskAdapter.notifyItemInserted(0);
                recyclerView.scrollToPosition(0);
                saveTasks();
                updateEmptyState();
                dialog.dismiss();
            } else {
                etTitle.setError("শিরোনাম আবশ্যক");
            }
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    @Override
    public void onTaskClick(Task task, int position) {
        saveTasks();
    }

    @Override
    public void onDeleteClick(Task task, int position) {
        if (position >= 0 && position < taskList.size()) {
            taskList.remove(position);
            taskAdapter.notifyItemRemoved(position);
            saveTasks();
            updateEmptyState();
        }
    }

    private void updateEmptyState() {
        if (taskList.isEmpty()) {
            tvEmptyState.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmptyState.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void saveTasks() {
        try {
            JSONArray jsonArray = new JSONArray();
            for (Task task : taskList) {
                JSONObject obj = new JSONObject();
                obj.put("id", task.getId());
                obj.put("title", task.getTitle());
                obj.put("description", task.getDescription());
                obj.put("isCompleted", task.isCompleted());
                jsonArray.put(obj);
            }
            sharedPreferences.edit().putString(KEY_TASKS, jsonArray.toString()).apply();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void loadTasks() {
        taskList.clear();
        String jsonString = sharedPreferences.getString(KEY_TASKS, null);
        if (jsonString != null) {
            try {
                JSONArray jsonArray = new JSONArray(jsonString);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    String id = obj.getString("id");
                    String title = obj.getString("title");
                    String description = obj.getString("description");
                    boolean isCompleted = obj.getBoolean("isCompleted");
                    taskList.add(new Task(id, title, description, isCompleted));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
